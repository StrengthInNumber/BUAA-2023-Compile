package Frontend.Lexer.Token;

public class SimpleToken extends Token{
    public SimpleToken(TokenType type, int lineNum, String content){
        super(type, lineNum, content);
    }
}
