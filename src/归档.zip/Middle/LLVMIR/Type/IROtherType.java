package Middle.LLVMIR.Type;

public class IROtherType extends IRType {
    public static IROtherType BASIC_BLOCK = new IROtherType();
    public static IROtherType FUNCTION = new IROtherType();
    public static IROtherType MODULE = new IROtherType();
}
