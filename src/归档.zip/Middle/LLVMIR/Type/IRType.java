package Middle.LLVMIR.Type;

public class IRType {
    public int getEleNum(){
        return 0;
    }
}
