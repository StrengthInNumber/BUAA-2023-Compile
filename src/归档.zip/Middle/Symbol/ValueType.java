package Middle.Symbol;

public enum ValueType {
    VOID,
    INT
}
