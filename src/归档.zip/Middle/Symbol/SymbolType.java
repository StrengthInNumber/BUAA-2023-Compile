package Middle.Symbol;

public enum SymbolType {
    SYMBOL_FUNC,
    SYMBOL_VAR,
    SYMBOL_CONST
}